// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMAC_NXN_H
#define XMAC_NXN_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmac_nxn_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XMac_nxn_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMac_nxn;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMac_nxn_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMac_nxn_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMac_nxn_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMac_nxn_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XMac_nxn_Initialize(XMac_nxn *InstancePtr, UINTPTR BaseAddress);
XMac_nxn_Config* XMac_nxn_LookupConfig(UINTPTR BaseAddress);
#else
int XMac_nxn_Initialize(XMac_nxn *InstancePtr, u16 DeviceId);
XMac_nxn_Config* XMac_nxn_LookupConfig(u16 DeviceId);
#endif
int XMac_nxn_CfgInitialize(XMac_nxn *InstancePtr, XMac_nxn_Config *ConfigPtr);
#else
int XMac_nxn_Initialize(XMac_nxn *InstancePtr, const char* InstanceName);
int XMac_nxn_Release(XMac_nxn *InstancePtr);
#endif

void XMac_nxn_Start(XMac_nxn *InstancePtr);
u32 XMac_nxn_IsDone(XMac_nxn *InstancePtr);
u32 XMac_nxn_IsIdle(XMac_nxn *InstancePtr);
u32 XMac_nxn_IsReady(XMac_nxn *InstancePtr);
void XMac_nxn_Continue(XMac_nxn *InstancePtr);
void XMac_nxn_EnableAutoRestart(XMac_nxn *InstancePtr);
void XMac_nxn_DisableAutoRestart(XMac_nxn *InstancePtr);

void XMac_nxn_Set_array_input_a_0(XMac_nxn *InstancePtr, u64 Data);
u64 XMac_nxn_Get_array_input_a_0(XMac_nxn *InstancePtr);
void XMac_nxn_Set_array_input_a_1(XMac_nxn *InstancePtr, u64 Data);
u64 XMac_nxn_Get_array_input_a_1(XMac_nxn *InstancePtr);
void XMac_nxn_Set_array_input_b_0(XMac_nxn *InstancePtr, u64 Data);
u64 XMac_nxn_Get_array_input_b_0(XMac_nxn *InstancePtr);
void XMac_nxn_Set_array_input_b_1(XMac_nxn *InstancePtr, u64 Data);
u64 XMac_nxn_Get_array_input_b_1(XMac_nxn *InstancePtr);
void XMac_nxn_Set_result_0(XMac_nxn *InstancePtr, u64 Data);
u64 XMac_nxn_Get_result_0(XMac_nxn *InstancePtr);
void XMac_nxn_Set_result_1(XMac_nxn *InstancePtr, u64 Data);
u64 XMac_nxn_Get_result_1(XMac_nxn *InstancePtr);

void XMac_nxn_InterruptGlobalEnable(XMac_nxn *InstancePtr);
void XMac_nxn_InterruptGlobalDisable(XMac_nxn *InstancePtr);
void XMac_nxn_InterruptEnable(XMac_nxn *InstancePtr, u32 Mask);
void XMac_nxn_InterruptDisable(XMac_nxn *InstancePtr, u32 Mask);
void XMac_nxn_InterruptClear(XMac_nxn *InstancePtr, u32 Mask);
u32 XMac_nxn_InterruptGetEnabled(XMac_nxn *InstancePtr);
u32 XMac_nxn_InterruptGetStatus(XMac_nxn *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
