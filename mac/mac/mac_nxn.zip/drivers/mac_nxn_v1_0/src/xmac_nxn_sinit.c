// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xmac_nxn.h"

extern XMac_nxn_Config XMac_nxn_ConfigTable[];

#ifdef SDT
XMac_nxn_Config *XMac_nxn_LookupConfig(UINTPTR BaseAddress) {
	XMac_nxn_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XMac_nxn_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XMac_nxn_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XMac_nxn_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMac_nxn_Initialize(XMac_nxn *InstancePtr, UINTPTR BaseAddress) {
	XMac_nxn_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMac_nxn_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMac_nxn_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XMac_nxn_Config *XMac_nxn_LookupConfig(u16 DeviceId) {
	XMac_nxn_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMAC_NXN_NUM_INSTANCES; Index++) {
		if (XMac_nxn_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMac_nxn_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMac_nxn_Initialize(XMac_nxn *InstancePtr, u16 DeviceId) {
	XMac_nxn_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMac_nxn_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMac_nxn_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

